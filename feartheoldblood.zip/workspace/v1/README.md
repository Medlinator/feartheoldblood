To install MongoDB:

    sudo apt-get install -y mongodb-org
    
MongoDB is preinstalled in your workspace. To run 
MongoDB, run the following below (passing the correct 
parameters to it). Mongodb data will be stored in the 
folder data. Make data directory outside of workspace.

    $ mkdir data
    $ echo 'mongod --bind_ip=$IP --dbpath=data --nojournal --rest "$@"' > mongod
    $ chmod a+x mongod
    
You can start mongodb by running the mongod script on your project root:

    $ ./mongod

Meanwhile, after you're up and running with mongo, 
be sure to shut down your mongod server each time 
you're done working. You can do this with ctrl + c.

If you leave it running then Cloud 9 could timeout 
and cause mongo to crash. If this happens, try the 
following steps to repair it.

From the command line, run:

    cd ~
    ./mongod --repair

If you're still having trouble getting it to run then
find the /data directory (it should be inside of ~ or
~/workspace) and cd into it. Once inside, run rm 
mongod.lock then cd back into ~ and run ./mongod again
(see below).

    cd ~/data
    rm mongod.lock
    cd
    ./mongod
    
Display information in specific collection

    db.collection.find()
    
To install Heroku

    heroku
    
Login to Heroku

    heroku login

Make app on Heroku servers

    heroku create
    
Deploy your code to Heroku

    git push heroku master
    
View Heroku errors

    heroku logs

To start app.js, a script will need to be placed in package.json under scripts. 

    "start": "node app.js"

Type q to exit git log.

    q
    
Remove remote git

    git remote rm heroku

Add remote git

    heroku git:remote -a newname
    

Create DATABASEURL environment variable

    export DATABASEURL=mongodb://localhost/fear_the_old_blood
    
