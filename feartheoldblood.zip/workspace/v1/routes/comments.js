var Artwork    = require("../models/artwork"),
    Comment    = require("../models/comment"),
    express    = require("express"),
    manager    = require("connect-ensure-login"),
    middleware = require("../middleware"),
    router     = express.Router({mergeParams: true});
    
// NEW
router.get("/new", manager.ensureLoggedIn(), function(req, res){
    Artwork.findById(req.params.id, function(err, artwork){
        if(err){
            console.log(err);
        } else {
            res.render("comments/new", {artwork: artwork});
        }
    });
});

// CREATE
router.post("/", manager.ensureLoggedIn(), function(req, res){
    Artwork.findById(req.params.id, function(err, artwork){
        if(err){
            console.log(err);
            res.redirect("/artwork");
        } else{
            Comment.create(req.body.comment, function(err, comment){
                if(err){
                    console.log(err);
                } else {
                    // Ties username and ID to comment
                    comment.author.id = req.user._id;
                    comment.author.username = req.user.username;
                    
                    // Saves comment
                    comment.save();
                    artwork.comments.push(comment);
                    artwork.save();
                    req.flash("success", "Successfully added comment");
                    res.redirect("/artwork/" + artwork._id);
                }
            });
        }
    });
});

// EDIT COMMENT
router.get("/:comment_id/edit", middleware.checkCommentOwnership, function(req, res){
    Comment.findById(req.params.comment_id, function(err, foundComment){
        if(err){
            res.redirect("back");
        } else {
            res.render("comments/edit", {artwork_id: req.params.id, comment: foundComment});
        }
    });
});

// UPDATE COMMENT
router.put("/:comment_id", middleware.checkCommentOwnership, function(req,res){
    Comment.findByIdAndUpdate(req.params.comment_id, req.body.comment, function(err, updatedComment){
        if(err){
            res.redirect("back");
        } else {
            req.flash("success", "Successfully updated comment");
            res.redirect("/artwork/" + req.params.id);
        }
    });
});

// DESTROY COMMENT
router.delete("/:comment_id", middleware.checkCommentOwnership, function(req, res){
    Comment.findByIdAndRemove(req.params.comment_id, function(err){
        if(err){
            res.redirect("back");
        } else {
            req.flash("success", "Comment deleted successfully");
            res.redirect("/artwork/" + req.params.id);
        }
    });
});

module.exports = router;