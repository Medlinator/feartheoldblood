var Artwork    = require("../models/artwork"),
    express    = require("express"),
    manager    = require("connect-ensure-login"), 
    middleware = require("../middleware"),
    router     = express.Router();

// INDEX
router.get("/", function(req, res){
    // Grabs all artwork from database
    Artwork.find({}, function(err, allArtwork){
        if(err){
            console.log(err);
        } else {
            res.render("artwork/index", {artwork: allArtwork});
        }
    });
});

// CREATE
router.post("/", manager.ensureLoggedIn(), function(req, res){
    // collects date from form on /artwork/new and adds it to the artwork array
    var title = req.body.title;
    var image = req.body.image;
    var desc =  req.body.description;
    var author = {
        id: req.user._id,
        username: req.user.username
    };
    var newArtwork = {title: title, image: image, description: desc, author: author};
    // Create a new campground and save to database
    Artwork.create(newArtwork, function(err, artwork){
        if(err){
            console.log(err);
        } else {
            req.flash("success", "Successfully added artwork");
            res.redirect("/artwork");
        }
    });
});

// NEW
router.get("/new", manager.ensureLoggedIn(), function(req, res){
    res.render("artwork/new");
});

// SHOW
router.get("/:id", function(req, res){
    // Find the selected artwork by ID
    Artwork.findById(req.params.id).populate("comments").exec(function(err, showArtwork){
        if(err){
            console.log(err);
        } else {
            res.render("artwork/show", {artwork: showArtwork});
        }
    });
});

// EDIT ARTWORK
router.get("/:id/edit", middleware.checkArtworkOwnership, function(req, res){
    Artwork.findById(req.params.id, function(err, foundArtwork){
        if(err){
            console.log(err);
        } else {
        res.render("artwork/edit", {artwork: foundArtwork});
        }
    });
});

// UPDATE ARTWORK
router.put("/:id", middleware.checkArtworkOwnership, function(req, res){
    // Find and update the correct artwork
    Artwork.findByIdAndUpdate(req.params.id, req.body.campground, function(err, updatedArtwork){
        if(err){
            res.redirect("/artwork");
        } else {
            req.flash("success", "Successfully updated artwork");
            res.redirect("/artwork/" + req.params.id);
        }
    });
});

// DESTROY ARTWORK
router.delete("/:id", middleware.checkArtworkOwnership, function(req, res){
    Artwork.findByIdAndRemove(req.params.id, function(err){
      if(err){
          res.redirect("back");
      } else {
          req.flash("success", "Successfully deleted artwork");
          res.redirect("/artwork");
      }
   });
});

module.exports = router;