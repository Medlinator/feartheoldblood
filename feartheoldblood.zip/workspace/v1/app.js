var bodyParser     = require("body-parser"), // Makes it easier to send JSON back and forth from back-end to front-end
    express        = require("express"), // Creates the framework for making routes
    flash          = require("connect-flash"),
    LocalStrategy  = require("passport-local"),
    methodOverride = require("method-override"),
    mongoose       = require("mongoose"), // Middleware to simplify use of MongoDB
    passport       = require("passport"),
    seedDB         = require("./seeds"), // Imports seedDB function from seeds.js
    url            = process.env.DATABASEURL || "mongodb://localhost/fear_the_old_blood", // Assigns the environment variable DATABASEURL to url if existing, otherwise assigns local hosted db
    User           = require("./models/user"),
    app            = express();
    
// REQUIRING ROUTES
var commentRoutes = require("./routes/comments"),
    artworkRoutes = require("./routes/artwork"),
    indexRoutes   = require("./routes/index");

mongoose.Promise = global.Promise;
mongoose.connect(url); // Connects app.js to database
app.use(bodyParser.urlencoded({extended: true})); // The value can only be a string or array when extended is false, and any type when extended is true
app.set("view engine", "ejs"); // Makes the default file type EJS
app.use(express.static(__dirname + "/public")); // Adds the public folder to the server directory
app.use(methodOverride("_method"));
app.use(flash());
//seedDB(); // Wipes database and populates with new pseudo data

// PASSPORT CONFIGURATION
app.use(require("express-session")({
    secret: "Once again, Theo wins the cutest baby!",
    resave: false,
    saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

app.use(function(req, res, next){
    res.locals.currentUser = req.user;
    res.locals.error = req.flash("error");
    res.locals.success = req.flash("success");
    next();
});

app.use("/", indexRoutes);
app.use("/artwork", artworkRoutes);
app.use("/artwork/:id/comments", commentRoutes);


// STARTS SERVER
app.listen(process.env.PORT, process.env.IP, function(){
    console.log("The FtOB server has started!");
});