var Artwork  = require("./models/artwork"),
    Comment  = require("./models/comment");

var data = [
    {
        title:       "Cleric Beast",
        image:       "http://t07.deviantart.net/fKn-MR138mHJHROlqfV-tFWh6OY=/fit-in/700x350/filters:fixed_height(100,100):origin()/pre14/18c2/th/pre/f/2015/364/c/f/cleric_beast_by_painted_bees-d9m10sm.jpg",
        description: "The Cleric Beast is an enormous creature with disfigured horns. With high agility and superhuman strength, this boss should not be taken lightly. This creature owes its name to a rumor which states that members of the Healing Church would eventually transform into the most hideous beasts."
    },
    {
        title:       "Ludwig, The Holy Blade",
        image:       "https://cdn1.artstation.com/p/assets/images/images/001/666/713/large/edward-delandre-ludwig-the-holy-blade-web.jpg?1450444989",
        description: "Ludwig was the first hunter of the Church, known as the 'Holy Blade', and a man emulating the heroes from an age of honor and chivalry."
    },
    {
        title:       "Moon Presence",
        image:       "https://t02.deviantart.net/bbRfHtPLVP6oVXJ5BBJxD85NZ3E=/fit-in/700x350/filters:fixed_height(100,100):origin()/pre00/f00e/th/pre/i/2016/005/8/e/162_365_bloodborne_4_by_snatti89-d9mv2qy.png",
        description: "An eldritch being composed of human flesh and bone, with the exception of its head. It's the Great One which created and rules the Hunter's Dream."
    },
    {
        title:       "Eileen the Crow",
        image:       "https://t11.deviantart.net/BxENlQ--HoXY49ViDmaHSo6MaZM=/fit-in/700x350/filters:fixed_height(100,100):origin()/pre03/bcb1/th/pre/i/2016/317/3/9/___may_the_good_blood_guide_your_way____by_sangrde-daoape3.jpg",
        description: "Eileen is an assassin whose sworn duty is to dispose of other hunters that have been corrupted by their lust for blood."
    }
];

function seedDB(){
    // Removes all artwork in database
    Artwork.remove({}, function(err){
        if(err){
            console.log(err);
        } else {
            console.log("Removed All Artwork in Database");
        }
    });
    
    // Removes all comments in database
    Comment.remove({}, function(err){
        if(err){
            console.log(err);
        } else {
            console.log("Removed All Comments in Database");
        }
    });
            
    // Adds artwork and comments to database
    data.forEach(function(seed){
        Artwork.create(seed, function(err, artwork){
            if(err){
                console.log(err);
            } else {
                console.log("Added Artwork to Database");
                Comment.create(
                    {
                        text:   "This artwork is fantastic!",
                        author: "Dickbutt"
                    },
                    function(err,comment){
                        if(err){
                            console.log(err);
                        } else {
                            artwork.comments.push(comment);
                            artwork.save();
                            console.log("Added New Comment!");
                        }
                    }
                );
            }
        });
    });
}

module.exports = seedDB;